#pragma once

#ifdef __cplusplus
#extern "C" {
#endif
  void initAutoGemmClKernels(void);
#ifdef __cplusplus
}
#endif

