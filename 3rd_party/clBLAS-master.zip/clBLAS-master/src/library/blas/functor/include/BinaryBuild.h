#ifndef _BINARY_BUILD_
#define _BINARY_BUILD_

//#include "CL\opencl.h"
//manage if we use cl binaries or cl source code
//#define BUILD_KERNEL_FROM_STRING 1

//find if we use in 32 or 64 bits ISA
//extern /*char * _64Bits;*/cl_uint _64Bits;
#endif  //_BINARY_BUILD_